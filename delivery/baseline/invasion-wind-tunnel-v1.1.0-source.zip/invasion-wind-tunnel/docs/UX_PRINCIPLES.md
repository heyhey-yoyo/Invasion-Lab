# UX principles

1. Default to a runnable preset rather than an empty model.
2. Use biological language before raw numerical parameters.
3. Keep Play mode under four decisions.
4. Allow one meaningful perturbation per run.
5. Describe the current event in natural language.
6. Present the outcome before the mechanism explanation.
7. Separate Play, Explore and Lab controls.
8. Never rely on color alone for a critical state.
9. Preserve seed, configuration and model version in exported results.
10. Repeat the scientific boundary at the interface and export levels.
