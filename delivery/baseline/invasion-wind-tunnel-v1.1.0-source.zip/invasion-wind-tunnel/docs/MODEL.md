# Model description

## 1. Purpose

The model is a qualitative, two-dimensional mechanism demonstrator for collective cancer-cell invasion through a narrow tissue opening. It is designed to produce interpretable differences between four morphological outcomes rather than patient-specific predictions.

## 2. State

Each cell stores position, velocity, previous direction, local pressure, passage state, leader state, transient stretch, neighbor count, motility heterogeneity, and lateral bias.

The world contains a fixed vertical barrier, one adjustable opening, a rightward chemotactic preference, and reflective outer boundaries.

## 3. Direction update

A cell's preferred direction combines:

- rightward chemotactic bias;
- direction persistence;
- normalized mean velocity of nearby cells;
- local cohesion toward neighboring cells;
- leader attraction when leader mode is active;
- local gap-centering bias;
- stochastic angular noise.

The direction layer does not directly teleport or place cells. It only contributes a desired movement vector.

## 4. Mechanical approximation

The position layer uses a soft-particle approximation:

- short-range repulsion prevents excessive overlap;
- medium-range attraction approximates cell-cell adhesion;
- a wall force prevents crossing outside the opening;
- narrow openings reduce forward mobility according to geometry and deformability;
- local overlap and wall penetration produce a pressure proxy;
- cells are rendered as velocity-aligned ellipses with transient stretch near the opening.

This is not a Cellular Potts Model. The `SimulationEngine` API is intentionally isolated so that a later Artistoo adapter can replace the position layer.

## 5. Events

The engine detects:

- first barrier contact;
- first passage;
- 50% passage;
- first cluster fragmentation;
- first isolated escaped cell;
- local jamming;
- unjamming after jamming;
- perturbation start and end;
- experiment completion.

## 6. Outcome classification

Classification uses passage rate, largest connected-component fraction, number of fragments, isolated escaped-cell fraction, jamming state, and configuration context. The public presets are regression-tested to produce the four MVP outcomes under the default seed.

## 7. Reproducibility

The engine uses a seeded Mulberry32-style pseudorandom generator. A saved experiment includes app version, model version, seed, normalized parameters, perturbation, metrics and events.

## 8. Worker timing and result delivery

Version 1.1.0 separates the Worker scheduler from the simulation engine. The scheduler uses a fixed 1/30-second simulation step and an elapsed-time accumulator. Playback labels therefore represent approximate simulation-time multipliers rather than arbitrary numbers of engine steps per browser timer callback.

Every emitted frame is independent, and completion always sends a final frame followed by exactly one result message. Result delivery no longer depends on the completion step matching a rendering stride.

## 9. Input normalization

All external configuration sources—URL query parameters, local saves and advanced controls—pass through `makeConfig`. Non-finite values use the selected preset fallback, numeric values are clamped, and the seed is stored as an integer in the inclusive range 1 to 4,294,967,295. The recorded seed therefore matches the random sequence used by the engine.
