# Validation report — v1.1.0

## Automated command

```bash
npm ci
npm run check
```

## Result

- Static validation: passed
- Node test runner: 13/13 passed
- Static build: passed
- HTTP smoke checks: passed
- Secret-pattern scan: passed; no likely credential files or values found

## Covered regressions

1. Numeric configuration is finite, bounded and versioned.
2. Seed `0`, negative, overflow and malformed values cannot diverge from the displayed seed.
3. Four outcome classifier modes remain covered.
4. Invasion-map heuristic behavior remains stable.
5. Identical seeds produce identical frames.
6. A non-frame-aligned maximum time terminates exactly.
7. Only one perturbation is accepted.
8. Every preset completes with finite metrics.
9. Four published presets produce four distinct MVP outcomes.
10. Playback speed is finite and bounded.
11. 0.5×, 1× and 2× advance approximately their labelled simulation time.
12. Completion at a step not divisible by the old frame stride still emits a final frame and exactly one result.
13. Single-step completion also emits the result.

## Static validation

The validator checks:

- duplicate HTML IDs;
- missing `aria-labelledby` targets;
- buttons without explicit types;
- HTML-linked local assets;
- manifest identity, scope and icons;
- all service-worker offline assets across `src`, `public` and `presets`;
- JavaScript syntax for every source script;
- presence of the static `_headers` file.

## HTTP smoke result

Using the included static server against `dist`:

| Resource | Result |
|---|---|
| `/` | 200, HTML |
| `/app.js` | 200, JavaScript |
| `/simulation/worker-runtime.js` | 200, JavaScript |
| `/manifest.webmanifest` | 200, web manifest |
| missing JavaScript resource | 404, plain text |
| `HEAD /index.html` | 200 |

The missing-resource check is important because the previous local server and service worker could hide missing assets behind `index.html`.

## Manual acceptance checklist

- Start, pause, continue, single-step and reset.
- Run all four presets to their final result cards.
- Apply exactly one perturbation.
- Replay timeline events.
- Export JSON, CSV and PNG.
- Save and load settings.
- Open a shared URL with malformed query values and confirm safe fallback.
- Test keyboard navigation through mode controls and preset radios.
- Test offline reload after one successful online load.

## Environment limitation

The execution environment blocked Chromium navigation to localhost with `ERR_BLOCKED_BY_ADMINISTRATOR`. Browser screenshot regression and an automated accessibility tree inspection were therefore not claimed as passed. Runtime logic, syntax, static assets, build output and HTTP behavior were verified independently.
