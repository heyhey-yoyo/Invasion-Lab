# Scientific scope and limitations

## Intended use

- education about adhesion, deformation, collective alignment, geometry and jamming;
- qualitative hypothesis exploration;
- classroom demonstrations and science communication;
- reproducible comparison of simplified rule sets.

## Not intended for

- clinical prediction;
- treatment selection;
- patient-specific prognosis;
- pathology diagnosis;
- quantitative inference of real migration rates;
- replacement of experimental validation or calibrated research simulators.

## Simplifications

- two-dimensional geometry;
- one cancer-cell population;
- no immune cells, fibroblasts, vasculature, drugs or clonal evolution;
- static barrier and single chemotactic direction;
- normalized parameters rather than physical units;
- soft-particle mechanics rather than a full CPM or finite-element tissue model;
- no cell division, death, ECM degradation or intracellular signalling.

## Interpretation rule

Outputs should be read as: “under these simplified assumptions, this rule combination tends to produce this visual pattern.” They should not be read as probabilities for a patient or biological specimen.
