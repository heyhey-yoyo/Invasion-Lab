import test from 'node:test';
import assert from 'node:assert/strict';
import { PRESETS, classifyOutcome, heuristicPhase, makeConfig } from '../src/simulation/model.js';
import { SimulationEngine } from '../src/simulation/engine.js';

test('configuration is clamped, sanitized, and versioned', () => {
  const config = makeConfig({
    presetId: 'unknown',
    adhesion: 9,
    deformability: -1,
    alignment: 'not-a-number',
    gapWidth: 500,
    cellCount: 2,
    maxTime: Number.NaN,
    seed: 0
  });
  assert.equal(config.presetId, 'collective');
  assert.equal(config.adhesion, 0.98);
  assert.equal(config.deformability, 0.05);
  assert.equal(config.alignment, PRESETS.collective.alignment);
  assert.equal(config.gapWidth, 92);
  assert.equal(config.cellCount, 24);
  assert.equal(config.maxTime, 42);
  assert.equal(config.seed, 1);
  assert.ok(config.modelVersion);
  assert.ok(config.appVersion);
});

test('custom configuration keeps custom identity and a valid uint32 seed', () => {
  const config = makeConfig({ presetId: 'custom', seed: 9e20, adhesion: 0.4 });
  assert.equal(config.presetId, 'custom');
  assert.equal(config.seed, 0xFFFFFFFF);
  assert.equal(config.adhesion, 0.4);
});

test('outcome classifier covers the four MVP modes', () => {
  assert.equal(classifyOutcome({ passRate: 0.02, integrity: .95, isolatedRate: 0, fragments: 1, jammed: true }, PRESETS.jam).id, 'jammed');
  assert.equal(classifyOutcome({ passRate: .7, integrity: .86, isolatedRate: .02, fragments: 1 }, PRESETS.collective).id, 'collective-advance');
  assert.equal(classifyOutcome({ passRate: .5, integrity: .58, isolatedRate: .1, fragments: 3 }, PRESETS.budding).id, 'tumor-budding');
  assert.equal(classifyOutcome({ passRate: .6, integrity: .3, isolatedRate: .5, fragments: 8 }, PRESETS.escape).id, 'single-cell-escape');
});

test('heuristic map responds to adhesion and deformability', () => {
  assert.equal(heuristicPhase(.9, .15, 30), 'jammed');
  assert.equal(heuristicPhase(.15, .9, 36), 'single-cell-escape');
  assert.equal(heuristicPhase(.85, .9, 44), 'collective-advance');
});

test('engine is deterministic for the same seed', () => {
  const a = new SimulationEngine({ ...PRESETS.collective, seed: 123, maxTime: 8 });
  const b = new SimulationEngine({ ...PRESETS.collective, seed: 123, maxTime: 8 });
  for (let i = 0; i < 180; i++) { a.step(); b.step(); }
  assert.deepEqual([...a.getFrame().data], [...b.getFrame().data]);
});

test('engine stops exactly at a non-frame-aligned maximum time', () => {
  const engine = new SimulationEngine({ ...PRESETS.jam, maxTime: 12.05 });
  while (!engine.finished) engine.step();
  assert.ok(Math.abs(engine.time - 12.05) < 1e-9);
});

test('only one perturbation is accepted per run', () => {
  const engine = new SimulationEngine(PRESETS.jam);
  assert.equal(engine.applyPerturbation('widen'), true);
  assert.equal(engine.applyPerturbation('soften'), false);
  assert.equal(engine.getResult().perturbation.type, 'widen');
});
