import test from 'node:test';
import assert from 'node:assert/strict';
import { PRESETS } from '../src/simulation/model.js';
import { SimulationEngine } from '../src/simulation/engine.js';

function runPreset(preset, maxTime = 24) {
  const engine = new SimulationEngine({ ...preset, maxTime, seed: 20260803 });
  while (!engine.finished) engine.step();
  return engine.getResult();
}

test('all presets run to completion with finite metrics', () => {
  for (const preset of Object.values(PRESETS)) {
    const result = runPreset(preset, 12);
    assert.ok(Number.isFinite(result.metrics.passRate));
    assert.ok(result.metrics.passRate >= 0 && result.metrics.passRate <= 1);
    assert.ok(result.mode.id);
    assert.ok(result.explanation.length > 20);
  }
});

test('the four published presets produce four distinct MVP outcomes', () => {
  const expected = {
    jam: 'jammed',
    collective: 'collective-advance',
    budding: 'tumor-budding',
    escape: 'single-cell-escape'
  };
  for (const [id, preset] of Object.entries(PRESETS)) {
    const result = runPreset(preset, 42);
    assert.equal(result.mode.id, expected[id], `${id} should produce ${expected[id]}`);
  }
});
