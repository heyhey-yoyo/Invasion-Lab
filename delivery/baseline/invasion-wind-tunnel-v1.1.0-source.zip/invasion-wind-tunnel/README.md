# Invasion Wind Tunnel｜肿瘤侵袭风洞

一个可直接静态部署的纯前端交互式生物物理实验室。用户通过少量生物学语义控制，观察癌细胞群体在狭窄组织缺口前出现拥堵、集体推进、肿瘤出芽或单细胞逃逸。

> 科学边界：本项目用于机制探索和教育，不用于临床预测、患者分层或治疗决策。

## v1.1.0 审查修复重点

- 修复部分实验结束后不发送最终结果、界面持续停留在运行状态的问题。
- 将 0.5×、1×、2× 播放倍率改为基于真实经过时间的固定时间步进。
- 对 URL、本地存档和高级输入中的非法数字、越界值及随机种子进行统一校验。
- 修复离线缓存把缺失脚本错误回退成 HTML 的问题，并限制缓存为同源、成功响应。
- 暂停或静止时不再持续重复绘制相同 Canvas 帧。
- 增加键盘语义、动态状态播报、显式按钮类型、进度条和对话框标签。
- 增加 Cloudflare/Netlify 静态响应头、Vercel 响应头、锁文件、Node 版本固定、PR CI 和 Dependabot。

## 已实现

- Play / Explore / Lab 三层交互模式
- 四个稳定预设：堵车、集体穿越、肿瘤出芽、单细胞逃逸
- 原生 Canvas 2D 暗场显微镜视图
- Web Worker 独立模拟线程与固定时间步运行时
- 黏附、形变、方向持续性、邻居对齐、趋化、leader 与噪声耦合
- 三个一次性扰动：扩大缺口、暂时降低黏附、提高形变能力
- 自动事件检测、时间轴与事件前后回放
- 首次通过时间、通过率、团块完整度、侵袭模式四项核心指标
- 固定随机种子、结果解释、侵袭地图、URL 分享、本地设置保存
- JSON、CSV、PNG 导出
- PWA 离线缓存与响应式布局

## 环境

项目没有第三方运行时依赖。推荐使用仓库固定的 Node.js 版本：

```bash
node --version   # v22.16.0
npm ci
```

Node.js 20 或更高版本也可运行。

## 本地运行

```bash
npm run dev
```

该命令先构建 `dist/`，再在 `http://127.0.0.1:4173` 启动本地静态服务器。

## 构建与验证

```bash
npm run check
npm run preview
```

`npm run check` 按顺序执行静态验证、13 项自动化测试和构建。发布目录为 `dist`。

## 部署

### Cloudflare Pages

- Build command：`npm run build`
- Build output directory：`dist`
- Node.js：读取 `.node-version`
- `public/_headers` 会进入构建产物，为静态页面添加 CSP、点击劫持防护、权限策略和缓存规则。

### GitHub Pages

1. 推送到 `main`。
2. 在 Settings → Pages 选择 GitHub Actions。
3. 部署工作流会执行 `npm ci`、完整检查、构建并上传 `dist`。

工作流中的官方 Action 固定到完整提交 SHA，PR 会由独立 CI 工作流验证。

### Netlify / Vercel

- Netlify 使用 `netlify.toml`。
- Vercel 使用 `vercel.json`，并配置与 Cloudflare 相同的核心安全响应头。

## 架构

```text
主线程
  UI / Canvas / 时间轴 / 回放 / 导出
       │ postMessage + Transferable Float32Array
       ▼
Simulation Worker Runtime
  固定时间步 / 播放倍率 / 最终结果交付
       ▼
Simulation Engine
  方向偏好 / 软粒子力学 / 屏障 / 事件 / 指标
```

本版本使用自研二维软粒子近似引擎，不包含 Artistoo 或 BIO-LGCA 源码。接口保持“方向偏好层—力学层—Worker 运行时—UI”分离，便于后续替换力学引擎。

## 主要限制

- 当前力学引擎不是 Cellular Potts Model，也未接入 Artistoo。
- 当前只实现二维狭窄缺口场景。
- 侵袭地图是快速机制启发式分类，不是完整多随机种子批量模拟。
- 回放使用浏览器会话中的关键帧，不是视频文件。
- 参数为归一化参数，未针对具体细胞系或患者数据标定。
- 当前审查环境无法用自动化 Chromium 打开本地地址，因此未生成浏览器截图回归；单元测试、静态检查、构建和 HTTP 资源检查均已执行。

详见 `docs/MODEL.md`、`docs/SCIENTIFIC_SCOPE.md` 和 `docs/VALIDATION.md`。
