import { SimulationWorkerRuntime } from './worker-runtime.js';

const runtime = new SimulationWorkerRuntime((message, transfer = []) => postMessage(message, transfer));
setInterval(() => runtime.tick(performance.now()), 16);
self.onmessage = event => runtime.handle(event.data || {}, performance.now());
