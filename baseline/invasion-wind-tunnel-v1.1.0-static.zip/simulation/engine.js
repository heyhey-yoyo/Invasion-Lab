import { classifyOutcome, explainOutcome, makeConfig, recommendControl } from './model.js';

const TAU = Math.PI * 2;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const length = (x, y) => Math.hypot(x, y) || 1;

class RNG {
  constructor(seed) { this.state = seed >>> 0 || 1; }
  next() {
    let t = this.state += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
  signed() { return this.next() * 2 - 1; }
}

export class SimulationEngine {
  constructor(inputConfig = {}) {
    this.config = makeConfig(inputConfig);
    this.width = 960;
    this.height = 540;
    this.barrierX = 548;
    this.gapY = 270;
    this.gapWidth = this.config.gapWidth;
    this.radius = 8.8;
    this.rng = new RNG(this.config.seed);
    this.time = 0;
    this.stepCount = 0;
    this.events = [];
    this.eventFlags = new Set();
    this.perturbation = null;
    this.tempAdhesionFactor = 1;
    this.tempDeformFactor = 1;
    this.perturbUntil = 0;
    this.jammed = false;
    this.finished = false;
    this.cells = this.#createCells();
    this.lastMetrics = this.getMetrics();
  }

  #createCells() {
    const cells = [];
    const n = this.config.cellCount;
    const cols = Math.ceil(Math.sqrt(n * 1.5));
    const spacingX = 16.2;
    const spacingY = 14.2;
    const rows = Math.ceil(n / cols);
    const originX = 330 - (cols * spacingX) / 2;
    const originY = this.gapY - (rows * spacingY) / 2;
    for (let i = 0; i < n; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const angle = this.rng.next() * TAU;
      cells.push({
        id: i,
        x: originX + col * spacingX + (row % 2) * spacingX * 0.5 + this.rng.signed() * 2.1,
        y: originY + row * spacingY + this.rng.signed() * 2.1,
        vx: Math.cos(angle) * 0.5,
        vy: Math.sin(angle) * 0.5,
        dirX: 1,
        dirY: 0,
        pressure: 0,
        passed: false,
        isLeader: this.config.leaderMode && i === Math.floor(rows / 2) * cols + cols - 1,
        budGroup: this.config.presetId === 'budding' && col >= cols - 2 && row >= 1 && row <= Math.min(rows - 2, 3) ? 1 : 0,
        motility: 1 + this.rng.signed() * this.config.noise * 1.35,
        lateralBias: this.rng.signed() * this.config.noise * 0.55,
        stretch: 0,
        neighborCount: 0,
        isolated: false
      });
    }
    return cells;
  }

  applyPerturbation(type) {
    if (this.perturbation) return false;
    const map = {
      widen: { label: '扩大缺口', apply: () => { this.gapWidth = Math.min(92, this.gapWidth + 22); } },
      loosen: { label: '暂时降低黏附', apply: () => { this.tempAdhesionFactor = 0.38; this.perturbUntil = this.time + 9; } },
      soften: { label: '提高形变能力', apply: () => { this.tempDeformFactor = 1.45; this.perturbUntil = this.time + 9; } }
    };
    const item = map[type];
    if (!item) return false;
    item.apply();
    this.perturbation = { type, label: item.label, time: this.time };
    this.#event('perturbation', item.label);
    return true;
  }

  step(dt = 1 / 30) {
    if (this.finished) return;
    const requestedDt = Number.isFinite(dt) && dt > 0 ? dt : 1 / 30;
    dt = Math.min(requestedDt, Math.max(0, this.config.maxTime - this.time));
    if (dt <= 0) {
      this.finished = true;
      this.#event('finished', '实验完成');
      return;
    }
    this.time += dt;
    this.stepCount++;
    if (this.perturbUntil && this.time >= this.perturbUntil) {
      this.tempAdhesionFactor = 1;
      this.tempDeformFactor = 1;
      this.perturbUntil = 0;
      this.#event('perturbation-ended', '扰动效应结束');
    }

    const n = this.cells.length;
    const fx = new Float32Array(n);
    const fy = new Float32Array(n);
    const neighborVX = new Float32Array(n);
    const neighborVY = new Float32Array(n);
    const centerX = new Float32Array(n);
    const centerY = new Float32Array(n);
    const counts = new Uint16Array(n);
    const adhesion = this.config.adhesion * this.tempAdhesionFactor;
    const deformability = clamp(this.config.deformability * this.tempDeformFactor, 0.05, 1);
    const neighborRadius = 31;
    const minDistance = this.radius * 1.72;

    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const a = this.cells[i];
        const b = this.cells[j];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = length(dx, dy);
        if (d < neighborRadius) {
          counts[i]++; counts[j]++;
          neighborVX[i] += b.vx; neighborVY[i] += b.vy;
          neighborVX[j] += a.vx; neighborVY[j] += a.vy;
          centerX[i] += b.x; centerY[i] += b.y;
          centerX[j] += a.x; centerY[j] += a.y;
          if (d < minDistance) {
            const overlap = minDistance - d;
            const push = overlap * 4.8;
            const nx = dx / d; const ny = dy / d;
            fx[i] -= nx * push; fy[i] -= ny * push;
            fx[j] += nx * push; fy[j] += ny * push;
            a.pressure += overlap * 0.04;
            b.pressure += overlap * 0.04;
          } else if (d < 25 && adhesion > 0.05) {
            const groupCoupling = a.budGroup === b.budGroup ? 1 : 0.24;
            const pull = adhesion * groupCoupling * (d - minDistance) * 0.22;
            const nx = dx / d; const ny = dy / d;
            fx[i] += nx * pull; fy[i] += ny * pull;
            fx[j] -= nx * pull; fy[j] -= ny * pull;
          }
        }
      }
    }

    const leader = this.cells.find(c => c.isLeader) || null;
    for (let i = 0; i < n; i++) {
      const cell = this.cells[i];
      cell.pressure *= 0.78;
      cell.neighborCount = counts[i];
      cell.isolated = counts[i] <= 1;

      let px = cell.vx; let py = cell.vy;
      let plen = length(px, py); px /= plen; py /= plen;
      let ax = counts[i] ? neighborVX[i] / counts[i] : px;
      let ay = counts[i] ? neighborVY[i] / counts[i] : py;
      let alen = length(ax, ay); ax /= alen; ay /= alen;
      let cx = counts[i] ? centerX[i] / counts[i] - cell.x : 0;
      let cy = counts[i] ? centerY[i] / counts[i] - cell.y : 0;
      let clen = length(cx, cy); cx /= clen; cy /= clen;

      const gapPull = clamp((this.gapY - cell.y) / 140, -0.55, 0.55);
      let dx = 1;
      let dy = gapPull + cell.lateralBias;
      if (cell.budGroup) {
        dx += 0.28;
        dy -= 0.16;
      }
      if (cell.passed) dy *= 0.25;
      if (leader && !cell.isLeader && this.config.leaderMode) {
        const ldx = leader.x - cell.x;
        const ldy = leader.y - cell.y;
        const ld = length(ldx, ldy);
        if (ld < 180) {
          dx += (ldx / ld) * this.config.alignment * 0.55;
          dy += (ldy / ld) * this.config.alignment * 0.55;
        }
      }

      const noiseAngle = this.rng.next() * TAU;
      let desiredX = dx * 1.1
        + px * this.config.persistence * 1.25
        + ax * this.config.alignment * 1.15
        + cx * adhesion * 0.72
        + Math.cos(noiseAngle) * this.config.noise;
      let desiredY = dy * 1.1
        + py * this.config.persistence * 1.25
        + ay * this.config.alignment * 1.15
        + cy * adhesion * 0.72
        + Math.sin(noiseAngle) * this.config.noise;
      const desiredLen = length(desiredX, desiredY);
      desiredX /= desiredLen; desiredY /= desiredLen;

      const wallDistance = Math.abs(cell.x - this.barrierX);
      const effectiveRadius = this.radius * (1.08 - deformability * 0.42);
      const inGap = Math.abs(cell.y - this.gapY) <= this.gapWidth / 2 - effectiveRadius;
      if (wallDistance < this.radius + 7 && !inGap) {
        const side = cell.x < this.barrierX ? -1 : 1;
        const penetration = this.radius + 7 - wallDistance;
        fx[i] += side * penetration * 11;
        const towardGap = Math.sign(this.gapY - cell.y);
        fy[i] += towardGap * penetration * (2.5 + deformability * 4);
        cell.pressure += penetration * 0.12;
      } else if (wallDistance < this.radius + 11 && inGap) {
        const easyWidth = this.radius * 3.7;
        const hardWidth = this.radius * 2.15;
        const geometricEase = clamp((this.gapWidth - hardWidth) / (easyWidth - hardWidth), 0, 1);
        const mobility = clamp(0.04 + geometricEase * 0.82 + deformability * 0.48, 0.06, 1.15);
        const tightness = 1 - geometricEase;
        cell.stretch = clamp(cell.stretch + (0.08 + tightness * 0.2) * deformability, 0, 1);
        desiredX *= mobility;
        if (mobility < 0.42 && cell.x < this.barrierX) fx[i] -= (0.42 - mobility) * 55;
      } else {
        cell.stretch *= 0.88;
      }

      const budBoost = cell.budGroup ? 1.28 : 1;
      const targetSpeed = this.config.speed * cell.motility * budBoost * (cell.isLeader ? 1.1 : 1) * (cell.passed ? 1.08 : 1);
      fx[i] += desiredX * targetSpeed * 2.4 - cell.vx * 2.2;
      fy[i] += desiredY * targetSpeed * 2.4 - cell.vy * 2.2;
    }

    for (let i = 0; i < n; i++) {
      const cell = this.cells[i];
      cell.vx += fx[i] * dt;
      cell.vy += fy[i] * dt;
      const maxSpeed = this.config.speed * 1.65;
      const s = length(cell.vx, cell.vy);
      if (s > maxSpeed) { cell.vx = cell.vx / s * maxSpeed; cell.vy = cell.vy / s * maxSpeed; }
      cell.x += cell.vx * dt;
      cell.y += cell.vy * dt;
      cell.x = clamp(cell.x, this.radius + 2, this.width - this.radius - 2);
      cell.y = clamp(cell.y, this.radius + 2, this.height - this.radius - 2);
      cell.dirX = cell.vx / length(cell.vx, cell.vy);
      cell.dirY = cell.vy / length(cell.vx, cell.vy);
      if (!cell.passed && cell.x > this.barrierX + this.radius + 4) cell.passed = true;
    }

    if (this.stepCount % 10 === 0) this.#detectEvents();
    if (this.time >= this.config.maxTime - 1e-9 || (this.lastMetrics.passRate > 0.94 && this.time > 10)) {
      this.finished = true;
      this.#event('finished', '实验完成');
    }
  }

  #event(type, label) {
    const key = ['perturbation', 'perturbation-ended'].includes(type) ? `${type}-${this.stepCount}` : type;
    if (this.eventFlags.has(key)) return;
    this.eventFlags.add(key);
    this.events.push({ id: `${type}-${this.stepCount}`, type, label, time: this.time, step: this.stepCount });
  }

  #detectEvents() {
    const contact = this.cells.filter(c => c.x + this.radius >= this.barrierX - 5 && c.x < this.barrierX).length;
    const passed = this.cells.filter(c => c.passed).length;
    const metrics = this.getMetrics();
    this.lastMetrics = metrics;
    if (contact > 0) this.#event('first-contact', '首次接触屏障');
    if (passed > 0) this.#event('first-pass', '首个细胞通过');
    if (passed >= this.cells.length / 2) this.#event('half-pass', '50% 细胞通过');
    if (metrics.fragments >= 2 && metrics.integrity < 0.82) this.#event('fragment', '第一次团块断裂');
    if (metrics.isolatedPassed > 0) this.#event('single-escape', '首个单细胞逃逸');
    const front = this.cells.filter(c => c.x > this.barrierX - 50 && c.x < this.barrierX + 15);
    const avgVx = front.length ? front.reduce((s, c) => s + Math.max(0, c.vx), 0) / front.length : 99;
    if (this.time > 4 && contact >= 8 && avgVx < 4.2 && passed / this.cells.length < 0.2) {
      this.jammed = true;
      this.#event('jam', '缺口处发生局部拥堵');
    }
    if (this.jammed && passed / this.cells.length > 0.22) this.#event('unjam', '群体发生解堵');
  }

  #components() {
    const n = this.cells.length;
    const seen = new Uint8Array(n);
    const sizes = [];
    for (let i = 0; i < n; i++) {
      if (seen[i]) continue;
      let size = 0;
      const stack = [i]; seen[i] = 1;
      while (stack.length) {
        const k = stack.pop(); size++;
        const a = this.cells[k];
        for (let j = 0; j < n; j++) {
          if (seen[j]) continue;
          const b = this.cells[j];
          if (Math.hypot(a.x - b.x, a.y - b.y) < 26) { seen[j] = 1; stack.push(j); }
        }
      }
      sizes.push(size);
    }
    sizes.sort((a, b) => b - a);
    return sizes;
  }

  getMetrics() {
    const passedCells = this.cells.filter(c => c.passed);
    const components = this.#components();
    const firstPass = this.events.find(e => e.type === 'first-pass');
    const isolatedPassed = passedCells.filter(c => c.isolated && c.x > this.barrierX + 35).length;
    return {
      elapsed: this.time,
      firstPassTime: firstPass?.time ?? null,
      passRate: passedCells.length / this.cells.length,
      integrity: (components[0] || 0) / this.cells.length,
      fragments: components.filter(s => s >= 2).length,
      isolatedPassed,
      isolatedRate: passedCells.length ? isolatedPassed / passedCells.length : 0,
      meanPressure: this.cells.reduce((s, c) => s + c.pressure, 0) / this.cells.length,
      jammed: this.jammed
    };
  }

  getStatus() {
    const m = this.lastMetrics;
    if (this.finished) return '实验完成，正在生成结果解释';
    if (!this.eventFlags.has('first-contact')) return '细胞群正在向组织屏障移动';
    if (!this.eventFlags.has('first-pass')) return '缺口处压力上升，前沿细胞正在尝试形变';
    if (m.passRate < 0.5) return '已有细胞通过，后方团块正在重新组织';
    return '超过一半细胞已经穿过组织边界';
  }

  getFrame() {
    const data = new Float32Array(this.cells.length * 9);
    let o = 0;
    for (const c of this.cells) {
      data[o++] = c.x; data[o++] = c.y; data[o++] = c.vx; data[o++] = c.vy;
      data[o++] = c.pressure; data[o++] = c.passed ? 1 : 0; data[o++] = c.isLeader ? 1 : 0;
      data[o++] = c.stretch; data[o++] = c.isolated ? 1 : 0;
    }
    const metrics = this.getMetrics();
    this.lastMetrics = metrics;
    return {
      data,
      meta: {
        time: this.time,
        step: this.stepCount,
        width: this.width,
        height: this.height,
        barrierX: this.barrierX,
        gapY: this.gapY,
        gapWidth: this.gapWidth,
        radius: this.radius,
        status: this.getStatus(),
        metrics,
        perturbation: this.perturbation,
        finished: this.finished
      }
    };
  }

  getResult() {
    const metrics = this.getMetrics();
    const mode = classifyOutcome(metrics, this.config);
    return {
      mode,
      metrics,
      explanation: explainOutcome(mode, metrics, this.config, this.perturbation),
      recommendation: recommendControl(mode),
      events: this.events,
      config: { ...this.config, gapWidthFinal: this.gapWidth },
      perturbation: this.perturbation,
      generatedAt: new Date().toISOString()
    };
  }
}
