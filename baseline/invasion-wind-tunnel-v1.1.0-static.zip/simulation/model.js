export const MODEL_VERSION = 'iwtx-agent-1.0.1';
export const APP_VERSION = '1.1.0';

export const LEVELS = {
  low: 0.2,
  medium: 0.55,
  high: 0.88
};

export const PRESETS = {
  jam: {
    id: 'jam', name: '堵车', subtitle: '高黏附、低形变、强协同',
    description: '细胞保持紧密团块，但狭窄缺口让前沿压力持续上升。',
    adhesion: 0.94, deformability: 0.08, alignment: 0.82, persistence: 0.68,
    noise: 0.05, speed: 20, gapWidth: 22, cellCount: 72, leaderMode: false
  },
  collective: {
    id: 'collective', name: '集体穿越', subtitle: '紧密协同、柔性变形',
    description: '前沿细胞变形后穿过缺口，后方细胞维持连接并连续推进。',
    adhesion: 0.78, deformability: 0.82, alignment: 0.86, persistence: 0.8,
    noise: 0.06, speed: 25, gapWidth: 39, cellCount: 68, leaderMode: true
  },
  budding: {
    id: 'budding', name: '肿瘤出芽', subtitle: '中等黏附、局部脱离',
    description: '主体仍然存在，但边缘小簇更容易脱离并穿过缺口。',
    adhesion: 0.46, deformability: 0.72, alignment: 0.48, persistence: 0.78,
    noise: 0.18, speed: 25, gapWidth: 31, cellCount: 66, leaderMode: true
  },
  escape: {
    id: 'escape', name: '单细胞逃逸', subtitle: '低黏附、高形变、低协同',
    description: '细胞更容易离开主体，以分散方式逐个穿越组织边界。',
    adhesion: 0.18, deformability: 0.92, alignment: 0.22, persistence: 0.84,
    noise: 0.2, speed: 28, gapWidth: 34, cellCount: 62, leaderMode: false
  }
};

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

export function makeConfig(input = {}) {
  const requestedPreset = typeof input.presetId === 'string' ? input.presetId : '';
  const preset = PRESETS[requestedPreset] || PRESETS.collective;
  const numberInRange = (value, fallback, min, max) => {
    const numeric = Number(value);
    return clamp(Number.isFinite(numeric) ? numeric : fallback, min, max);
  };
  const seedValue = Number(input.seed);
  const seed = Number.isFinite(seedValue)
    ? Math.trunc(clamp(seedValue, 1, 0xFFFFFFFF))
    : 20260803;
  const presetId = PRESETS[requestedPreset] ? requestedPreset : requestedPreset === 'custom' ? 'custom' : preset.id;

  return {
    id: preset.id,
    name: preset.name,
    subtitle: preset.subtitle,
    description: preset.description,
    adhesion: numberInRange(input.adhesion, preset.adhesion, 0.05, 0.98),
    deformability: numberInRange(input.deformability, preset.deformability, 0.05, 0.98),
    alignment: numberInRange(input.alignment, preset.alignment, 0, 0.98),
    persistence: numberInRange(input.persistence, preset.persistence, 0, 0.98),
    noise: numberInRange(input.noise, preset.noise, 0, 0.6),
    speed: numberInRange(input.speed, preset.speed, 10, 42),
    gapWidth: numberInRange(input.gapWidth, preset.gapWidth, 22, 92),
    cellCount: Math.round(numberInRange(input.cellCount, preset.cellCount, 24, 140)),
    maxTime: numberInRange(input.maxTime, 42, 12, 120),
    leaderMode: typeof input.leaderMode === 'boolean' ? input.leaderMode : preset.leaderMode,
    seed,
    presetId,
    modelVersion: MODEL_VERSION,
    appVersion: APP_VERSION
  };
}

export function classifyOutcome(metrics, config) {
  const passRate = metrics.passRate ?? 0;
  const integrity = metrics.integrity ?? 1;
  const isolatedRate = metrics.isolatedRate ?? 0;
  const fragments = metrics.fragments ?? 1;
  if (passRate < 0.12 || (metrics.jammed && passRate < 0.25)) {
    return { id: 'jammed', label: 'Jammed｜拥堵' };
  }
  if (isolatedRate > 0.26 || (config.adhesion < 0.3 && passRate > 0.2)) {
    return { id: 'single-cell-escape', label: 'Single-cell Escape｜单细胞逃逸' };
  }
  if ((fragments >= 2 && config.adhesion < 0.7) || (integrity < 0.68 && config.adhesion < 0.68)) {
    return { id: 'tumor-budding', label: 'Tumor Budding｜肿瘤出芽' };
  }
  if (passRate >= 0.35 && integrity >= 0.64) {
    return { id: 'collective-advance', label: 'Collective Advance｜集体推进' };
  }
  return { id: 'fingering', label: 'Fingering｜指状侵袭' };
}

export function explainOutcome(mode, metrics, config, perturbation) {
  const pct = Math.round((metrics.passRate || 0) * 100);
  const first = Number.isFinite(metrics.firstPassTime) ? `${metrics.firstPassTime.toFixed(1)} 秒` : '实验结束前';
  const perturb = perturbation
    ? `运行中施加的“${perturbation.label}”改变了局部条件。`
    : '本次没有施加额外扰动。';
  const text = {
    jammed: `这次实验形成明显拥堵。细胞保持较强连接，但形变能力与缺口宽度不足以释放前沿压力；${pct}% 的细胞完成穿越。`,
    'collective-advance': `这次实验形成集体穿越。细胞在约 ${first} 首次通过，并在维持团块连接的同时持续向外推进；最终通过率为 ${pct}%。`,
    'tumor-budding': `这次实验出现肿瘤出芽。主体团块仍然存在，但边缘形成了可独立运动的小型细胞簇；最终通过率为 ${pct}%。`,
    'single-cell-escape': `这次实验出现单细胞逃逸。较低黏附和较高形变使细胞更容易脱离主体并逐个穿过缺口；最终通过率为 ${pct}%。`,
    fingering: `这次实验形成指状侵袭。前沿沿缺口方向拉长，但群体尚未完全转变为稳定集体穿越或大量单细胞逃逸。`
  }[mode.id];
  return `${text} ${perturb}`;
}

export function recommendControl(mode) {
  const recommendations = {
    jammed: '推荐对照：保持细胞行为不变，仅扩大缺口，观察几何约束是否是主要瓶颈。',
    'collective-advance': '推荐对照：降低细胞黏附，观察连续细胞流是否转变为出芽或单细胞逃逸。',
    'tumor-budding': '推荐对照：提高邻居对齐，观察小型细胞芽是否重新并入集体推进。',
    'single-cell-escape': '推荐对照：提高细胞黏附，观察分散逃逸是否转变为集体穿越。',
    fingering: '推荐对照：分别提高形变能力与缺口宽度，比较哪一项更能促进完整穿越。'
  };
  return recommendations[mode.id];
}

export function heuristicPhase(adhesion, deformability, gapWidth = 36) {
  const opening = (gapWidth - 22) / 70;
  const throughput = deformability * 0.58 + opening * 0.42;
  if (throughput < 0.35 && adhesion > 0.5) return 'jammed';
  if (adhesion < 0.28 && deformability > 0.5) return 'single-cell-escape';
  if (adhesion < 0.68 && throughput > 0.42) return 'tumor-budding';
  if (adhesion > 0.62 && throughput > 0.48) return 'collective-advance';
  return 'fingering';
}
