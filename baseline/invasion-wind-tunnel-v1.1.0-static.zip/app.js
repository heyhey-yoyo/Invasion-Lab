import {
  APP_VERSION,
  MODEL_VERSION,
  PRESETS,
  classifyOutcome,
  makeConfig
} from './simulation/model.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

const elements = {
  presetGrid: $('#presetGrid'),
  canvas: $('#simulationCanvas'),
  canvasWrap: $('#canvasWrap'),
  hoverTip: $('#hoverTip'),
  replayBadge: $('#replayBadge'),
  start: $('#startExperiment'),
  playPause: $('#playPauseButton'),
  reset: $('#resetButton'),
  step: $('#stepButton'),
  speed: $('#speedSelect'),
  status: $('#stageStatus'),
  statusDot: $('#statusDot'),
  observation: $('#observationText'),
  limiting: $('#limitingFactor'),
  timeNow: $('#timeNow'),
  timeMax: $('#timeMax'),
  progress: $('#progressBar'),
  timeline: $('#timeline'),
  seedBadge: $('#seedBadge'),
  modelBadge: $('#modelBadge'),
  first: $('#metricFirst'),
  pass: $('#metricPass'),
  integrity: $('#metricIntegrity'),
  mode: $('#metricMode'),
  resultCard: $('#resultCard'),
  resultMode: $('#resultMode'),
  resultExplanation: $('#resultExplanation'),
  resultRecommendation: $('#resultRecommendation'),
  gapRange: $('#gapRange'),
  gapOutput: $('#gapOutput'),
  seedInput: $('#seedInput'),
  cellCountInput: $('#cellCountInput'),
  durationInput: $('#durationInput'),
  scienceDialog: $('#scienceDialog'),
  mapDialog: $('#mapDialog'),
  keyboardDialog: $('#keyboardDialog'),
  invasionMap: $('#invasionMap'),
  toast: $('#toast')
};

const ctx = elements.canvas.getContext('2d', { alpha: false });
const worker = new Worker('./simulation/worker.js', { type: 'module' });

const state = {
  mode: 'play',
  config: makeConfig(readUrlConfig()),
  running: false,
  started: false,
  completed: false,
  currentFrame: null,
  frames: [],
  events: [],
  result: null,
  perturbation: null,
  replay: null,
  hoveredCell: -1,
  installPrompt: null,
  needsRender: true
};

function readUrlConfig() {
  const q = new URLSearchParams(location.search);
  return {
    presetId: q.get('p') || 'collective',
    adhesion: q.has('a') ? Number(q.get('a')) : undefined,
    deformability: q.has('d') ? Number(q.get('d')) : undefined,
    alignment: q.has('l') ? Number(q.get('l')) : undefined,
    persistence: q.has('r') ? Number(q.get('r')) : undefined,
    noise: q.has('z') ? Number(q.get('z')) : undefined,
    speed: q.has('v') ? Number(q.get('v')) : undefined,
    leaderMode: q.has('h') ? q.get('h') === '1' : undefined,
    gapWidth: q.has('g') ? Number(q.get('g')) : undefined,
    seed: q.has('s') ? Number(q.get('s')) : undefined,
    cellCount: q.has('n') ? Number(q.get('n')) : undefined,
    maxTime: q.has('t') ? Number(q.get('t')) : undefined
  };
}

function renderPresets() {
  elements.presetGrid.replaceChildren(...Object.values(PRESETS).map(preset => {
    const selected = state.config.presetId === preset.id;
    const button = document.createElement('button');
    const title = document.createElement('strong');
    const subtitle = document.createElement('span');
    button.className = 'preset-card';
    button.type = 'button';
    button.setAttribute('role', 'radio');
    button.dataset.preset = preset.id;
    button.setAttribute('aria-checked', String(selected));
    button.tabIndex = selected ? 0 : -1;
    button.title = preset.description;
    title.textContent = preset.name;
    subtitle.textContent = preset.subtitle;
    button.append(title, subtitle);
    button.addEventListener('click', () => selectPreset(preset.id));
    button.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
      event.preventDefault();
      const ids = Object.keys(PRESETS);
      const offset = ['ArrowRight', 'ArrowDown'].includes(event.key) ? 1 : -1;
      const nextId = ids[(ids.indexOf(preset.id) + offset + ids.length) % ids.length];
      selectPreset(nextId);
      requestAnimationFrame(() => elements.presetGrid.querySelector(`[data-preset="${nextId}"]`)?.focus());
    });
    return button;
  }));
}

function selectPreset(id) {
  if (!PRESETS[id]) return;
  const preserved = { seed: state.config.seed, maxTime: state.config.maxTime };
  state.config = makeConfig({ ...PRESETS[id], ...preserved, presetId: id });
  renderPresets();
  syncControls();
  resetExperiment();
  showToast(`已载入“${PRESETS[id].name}”预设`);
}

function syncControls() {
  elements.gapRange.value = String(state.config.gapWidth);
  elements.gapOutput.value = String(Math.round(state.config.gapWidth));
  elements.gapOutput.textContent = `${Math.round(state.config.gapWidth)} px`;
  elements.seedInput.value = String(state.config.seed);
  elements.cellCountInput.value = String(state.config.cellCount);
  elements.durationInput.value = String(state.config.maxTime);
  elements.seedBadge.textContent = `Seed ${state.config.seed}`;
  elements.modelBadge.textContent = `Model ${MODEL_VERSION.replace('iwtx-agent-', '')}`;
  elements.timeMax.textContent = formatTime(state.config.maxTime, false);
  $$('.segmented').forEach(group => {
    const key = group.dataset.control;
    $$('button', group).forEach(button => {
      const value = Number(button.dataset.value);
      const active = Math.abs(value - state.config[key]) < 0.2;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  });
}

function setMode(mode) {
  if (!['play', 'explore', 'lab'].includes(mode)) return;
  state.mode = mode;
  $$('.mode-tab').forEach(button => {
    const active = button.dataset.mode === mode;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-selected', String(active));
    button.tabIndex = active ? 0 : -1;
  });
  $$('.mode-only').forEach(section => {
    section.hidden = !section.dataset.visibleMode.split(' ').includes(mode);
  });
}

function initWorker() {
  worker.postMessage({ type: 'init', config: state.config });
}

function resetExperiment() {
  worker.postMessage({ type: 'pause' });
  state.running = false;
  state.started = false;
  state.completed = false;
  state.frames = [];
  state.events = [];
  state.result = null;
  state.perturbation = null;
  state.replay = null;
  elements.replayBadge.hidden = true;
  elements.resultCard.hidden = true;
  const empty = document.createElement('p');
  empty.className = 'empty-state';
  empty.textContent = '事件将在实验运行后自动标注。';
  elements.timeline.replaceChildren(empty);
  state.needsRender = true;
  $$('.perturb-actions button').forEach(button => button.disabled = true);
  updateRunButtons();
  initWorker();
}

function startOrPause() {
  if (state.completed) {
    resetExperiment();
    setTimeout(startOrPause, 0);
    return;
  }
  if (state.replay) stopReplay();
  state.started = true;
  state.running = !state.running;
  worker.postMessage({ type: state.running ? 'start' : 'pause', speed: Number(elements.speed.value) });
  $$('.perturb-actions button').forEach(button => button.disabled = !state.running || Boolean(state.perturbation));
  updateRunButtons();
}

function updateRunButtons() {
  const label = state.completed ? '重新运行' : state.running ? '暂停实验' : state.started ? '继续实验' : '开始实验';
  $('span', elements.start).textContent = label;
  elements.playPause.textContent = state.running ? 'Ⅱ' : '▶';
  elements.playPause.setAttribute('aria-label', state.running ? '暂停实验' : state.completed ? '重新运行实验' : '开始实验');
  elements.step.disabled = state.running || state.completed;
  elements.statusDot.className = `status-dot ${state.running ? 'is-running' : state.started && !state.completed ? 'is-paused' : ''}`;
  if (!state.started) elements.status.textContent = '已加载推荐实验，等待开始';
  if (!state.running && state.started && !state.completed) elements.status.textContent = '实验已暂停';
}

function stepOnce() {
  if (state.running || state.completed) return;
  state.started = true;
  worker.postMessage({ type: 'step' });
  updateRunButtons();
}

function updateConfig(key, value) {
  state.config = makeConfig({ ...state.config, [key]: value, presetId: 'custom' });
  renderPresets();
  syncControls();
  resetExperiment();
}

function formatTime(seconds, decimals = true) {
  if (!Number.isFinite(seconds)) return '—';
  const mins = Math.floor(seconds / 60);
  const secs = seconds - mins * 60;
  return `${String(mins).padStart(2, '0')}:${secs.toFixed(decimals ? 1 : 0).padStart(decimals ? 4 : 2, '0')}`;
}

function updateMetrics(meta) {
  const m = meta.metrics;
  elements.first.textContent = Number.isFinite(m.firstPassTime) ? `${m.firstPassTime.toFixed(1)} s` : '—';
  elements.pass.textContent = `${Math.round(m.passRate * 100)}%`;
  elements.integrity.textContent = `${Math.round(m.integrity * 100)}%`;
  const provisional = meta.time > 3 ? classifyOutcome(m, state.config) : null;
  elements.mode.textContent = state.result?.mode.label || provisional?.label.split('｜')[1] || '观察中';
  elements.timeNow.textContent = formatTime(meta.time);
  elements.progress.style.width = `${clamp(meta.time / state.config.maxTime * 100, 0, 100)}%`;
  if (elements.observation.textContent !== meta.status) elements.observation.textContent = meta.status;
  if (elements.status.textContent !== meta.status) elements.status.textContent = meta.status;
  elements.progress.parentElement.setAttribute('aria-valuenow', String(Math.round(clamp(meta.time / state.config.maxTime * 100, 0, 100))));
  elements.limiting.textContent = limitingFactor(meta);
}

function limitingFactor(meta) {
  const { metrics } = meta;
  if (state.config.deformability < 0.35) return '形变能力';
  if (state.config.gapWidth < 34) return '缺口几何';
  if (state.config.adhesion > 0.78 && metrics.passRate < 0.15) return '团块拥堵';
  if (state.config.adhesion < 0.3) return '细胞连接';
  if (state.config.alignment < 0.3) return '方向协同';
  return '几何—力学平衡';
}

function addEvents(events) {
  if (!events?.length) return;
  if (state.events.length === 0) elements.timeline.replaceChildren();
  for (const event of events) {
    state.events.push(event);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'timeline-event';
    button.dataset.eventId = event.id;
    const time = document.createElement('time');
    const label = document.createElement('span');
    time.textContent = formatTime(event.time);
    label.textContent = event.label;
    button.append(time, label);
    button.addEventListener('click', () => replayEvent(event));
    elements.timeline.append(button);
  }
  elements.timeline.scrollLeft = elements.timeline.scrollWidth;
}

function replayEvent(event) {
  const sequence = state.frames.filter(frame => frame.meta.time >= event.time - 3 && frame.meta.time <= event.time + 4);
  if (sequence.length < 2) {
    showToast('该事件附近的回放帧尚未保存完整');
    return;
  }
  worker.postMessage({ type: 'pause' });
  state.running = false;
  state.replay = { frames: sequence, index: 0, last: 0, event };
  elements.replayBadge.textContent = `关键事件回放 · ${event.label}`;
  elements.replayBadge.hidden = false;
  state.needsRender = true;
  updateRunButtons();
}

function stopReplay() {
  state.replay = null;
  elements.replayBadge.hidden = true;
  state.needsRender = true;
}

function showResult(result) {
  state.result = result;
  state.completed = true;
  state.running = false;
  elements.resultCard.hidden = false;
  elements.resultMode.textContent = result.mode.label;
  elements.resultExplanation.textContent = result.explanation;
  elements.resultRecommendation.textContent = result.recommendation;
  elements.mode.textContent = result.mode.label.split('｜')[1] || result.mode.label;
  $$('.perturb-actions button').forEach(button => button.disabled = true);
  updateRunButtons();
  showToast('实验完成，结果解释已生成');
}

worker.addEventListener('message', event => {
  const message = event.data;
  if (message.type === 'frame') {
    const frame = { data: message.data, meta: message.meta };
    state.currentFrame = frame;
    state.needsRender = true;
    if (state.started && !state.replay) {
      state.frames.push(frame);
      if (state.frames.length > 3600) state.frames.shift();
    }
    if (message.meta.perturbation) state.perturbation = message.meta.perturbation;
    updateMetrics(message.meta);
    addEvents(message.events);
  } else if (message.type === 'result') {
    showResult(message.result);
  } else if (message.type === 'batch-result') {
    renderMap(message);
  }
});

function draw(timestamp) {
  requestAnimationFrame(draw);
  let frame = state.currentFrame;
  if (state.replay) {
    if (!state.replay.last || timestamp - state.replay.last > 70) {
      state.replay.last = timestamp;
      state.replay.index = (state.replay.index + 1) % state.replay.frames.length;
      state.needsRender = true;
    }
    frame = state.replay.frames[state.replay.index];
  }
  if (!frame || !state.needsRender) return;
  renderFrame(frame, timestamp);
  state.needsRender = false;
}

function renderFrame(frame, timestamp) {
  const { data, meta } = frame;
  const w = elements.canvas.width;
  const h = elements.canvas.height;
  ctx.clearRect(0, 0, w, h);

  const bg = ctx.createLinearGradient(0, 0, w, h);
  bg.addColorStop(0, '#071419');
  bg.addColorStop(.55, '#091a20');
  bg.addColorStop(1, '#061116');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  ctx.save();
  ctx.globalAlpha = .14;
  ctx.strokeStyle = '#87cec5';
  ctx.lineWidth = 1;
  for (let y = 35; y < h; y += 42) {
    ctx.beginPath();
    for (let x = meta.barrierX + 24; x < w; x += 18) {
      const wave = Math.sin((x + y + timestamp * .018) * .018) * 2;
      if (x === meta.barrierX + 24) ctx.moveTo(x, y + wave); else ctx.lineTo(x, y + wave);
    }
    ctx.stroke();
  }
  ctx.restore();

  const gapTop = meta.gapY - meta.gapWidth / 2;
  const gapBottom = meta.gapY + meta.gapWidth / 2;
  const wallGradient = ctx.createLinearGradient(meta.barrierX - 10, 0, meta.barrierX + 10, 0);
  wallGradient.addColorStop(0, 'rgba(89,112,120,.36)');
  wallGradient.addColorStop(.5, 'rgba(166,188,192,.68)');
  wallGradient.addColorStop(1, 'rgba(71,91,99,.32)');
  ctx.fillStyle = wallGradient;
  ctx.fillRect(meta.barrierX - 7, 0, 14, gapTop);
  ctx.fillRect(meta.barrierX - 7, gapBottom, 14, h - gapBottom);
  ctx.fillStyle = 'rgba(130,215,203,.13)';
  ctx.fillRect(meta.barrierX - 13, gapTop, 26, meta.gapWidth);
  ctx.strokeStyle = 'rgba(130,215,203,.48)';
  ctx.strokeRect(meta.barrierX - 13, gapTop, 26, meta.gapWidth);

  const cellCount = data.length / 9;
  for (let i = 0; i < cellCount; i++) {
    const o = i * 9;
    const x = data[o]; const y = data[o + 1];
    const vx = data[o + 2]; const vy = data[o + 3];
    const pressure = data[o + 4]; const passed = data[o + 5] > .5;
    const leader = data[o + 6] > .5; const stretch = data[o + 7]; const isolated = data[o + 8] > .5;
    const speed = Math.hypot(vx, vy) || 1;
    const angle = Math.atan2(vy, vx);
    const rx = meta.radius * (1 + stretch * .6);
    const ry = meta.radius * (1 - stretch * .28);

    ctx.save();
    ctx.globalAlpha = .24;
    ctx.strokeStyle = passed ? '#82d7cb' : '#d1a4c8';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - vx / speed * (7 + speed * .22), y - vy / speed * (7 + speed * .22));
    ctx.stroke();
    ctx.restore();

    if (pressure > .35) {
      const halo = ctx.createRadialGradient(x, y, 2, x, y, meta.radius * 2.3);
      halo.addColorStop(0, `rgba(231,199,125,${clamp(pressure * .08, .05, .3)})`);
      halo.addColorStop(1, 'rgba(231,199,125,0)');
      ctx.fillStyle = halo;
      ctx.beginPath(); ctx.arc(x, y, meta.radius * 2.3, 0, Math.PI * 2); ctx.fill();
    }

    ctx.save();
    ctx.translate(x, y); ctx.rotate(angle);
    ctx.beginPath(); ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    const fill = ctx.createLinearGradient(-rx, -ry, rx, ry);
    if (passed) { fill.addColorStop(0, '#7fcfc5'); fill.addColorStop(1, '#3e817d'); }
    else { fill.addColorStop(0, '#d4a9ca'); fill.addColorStop(1, isolated ? '#875d80' : '#8f6688'); }
    ctx.fillStyle = fill;
    ctx.globalAlpha = .82;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = pressure > .7 ? '#efd594' : leader ? '#dffbf7' : 'rgba(235,224,235,.48)';
    ctx.lineWidth = leader ? 2 : 1;
    ctx.stroke();
    ctx.beginPath(); ctx.ellipse(rx * .12, 0, rx * .28, ry * .34, 0, 0, Math.PI * 2);
    ctx.fillStyle = passed ? 'rgba(22,73,70,.48)' : 'rgba(72,38,67,.48)'; ctx.fill();
    ctx.restore();

    if (leader) {
      ctx.strokeStyle = 'rgba(221,255,250,.54)';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(x, y, meta.radius * 1.55, 0, Math.PI * 2); ctx.stroke();
    }
  }

  if (state.hoveredCell >= 0 && state.hoveredCell < cellCount) {
    const o = state.hoveredCell * 9;
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(data[o], data[o + 1], meta.radius * 1.8, 0, Math.PI * 2); ctx.stroke();
  }
}

function pointerToWorld(event) {
  const rect = elements.canvas.getBoundingClientRect();
  return {
    x: (event.clientX - rect.left) / rect.width * elements.canvas.width,
    y: (event.clientY - rect.top) / rect.height * elements.canvas.height,
    left: event.clientX - elements.canvasWrap.getBoundingClientRect().left,
    top: event.clientY - elements.canvasWrap.getBoundingClientRect().top
  };
}

elements.canvas.addEventListener('pointermove', event => {
  const frame = state.replay ? state.replay.frames[state.replay.index] : state.currentFrame;
  if (!frame) return;
  const point = pointerToWorld(event);
  let closest = -1; let min = 22;
  for (let i = 0; i < frame.data.length / 9; i++) {
    const dx = frame.data[i * 9] - point.x; const dy = frame.data[i * 9 + 1] - point.y;
    const d = Math.hypot(dx, dy);
    if (d < min) { min = d; closest = i; }
  }
  if (state.hoveredCell !== closest) state.needsRender = true;
  state.hoveredCell = closest;
  if (closest < 0) { elements.hoverTip.hidden = true; return; }
  const o = closest * 9;
  const pressure = frame.data[o + 4];
  const passed = frame.data[o + 5] > .5;
  const leader = frame.data[o + 6] > .5;
  const isolated = frame.data[o + 8] > .5;
  const sentence = leader
    ? '这是领头细胞。它具有更强的方向偏置，并向邻近细胞提供运动参照。'
    : passed
      ? `这个细胞已经穿过屏障，当前${isolated ? '与主体连接较弱，接近单细胞逃逸状态' : '仍与邻近细胞保持集体连接'}。`
      : pressure > .65
        ? '这个细胞正在受到后方挤压。局部压力较高，它会尝试向缺口方向滑移并发生形变。'
        : '这个细胞受到右侧趋化方向、方向记忆和邻居运动的共同影响。';
  elements.hoverTip.textContent = sentence;
  elements.hoverTip.hidden = false;
  elements.hoverTip.style.left = `${clamp(point.left + 12, 8, elements.canvasWrap.clientWidth - 248)}px`;
  elements.hoverTip.style.top = `${clamp(point.top + 12, 8, elements.canvasWrap.clientHeight - 82)}px`;
});
elements.canvas.addEventListener('pointerleave', () => { state.hoveredCell = -1; state.needsRender = true; elements.hoverTip.hidden = true; });

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.hidden = true;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportPayload() {
  return {
    app: { name: 'Invasion Wind Tunnel', version: APP_VERSION, modelVersion: MODEL_VERSION },
    config: state.config,
    result: state.result,
    events: state.events,
    savedAt: new Date().toISOString(),
    scientificScope: 'Mechanism exploration and education only; not for clinical prediction.'
  };
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add('is-visible');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => elements.toast.classList.remove('is-visible'), 2200);
}

function shareUrl() {
  const q = new URLSearchParams({
    p: state.config.presetId,
    a: state.config.adhesion.toFixed(2),
    d: state.config.deformability.toFixed(2),
    l: state.config.alignment.toFixed(2),
    r: state.config.persistence.toFixed(2),
    z: state.config.noise.toFixed(2),
    v: state.config.speed.toFixed(1),
    h: state.config.leaderMode ? '1' : '0',
    g: String(Math.round(state.config.gapWidth)),
    s: String(state.config.seed),
    n: String(state.config.cellCount),
    t: String(state.config.maxTime)
  });
  return `${location.origin}${location.pathname}?${q}`;
}

async function copyText(text, success) {
  try {
    if (!navigator.clipboard?.writeText) throw new Error('Clipboard API unavailable');
    await navigator.clipboard.writeText(text);
    showToast(success);
  } catch {
    const area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', '');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.append(area);
    area.select();
    const copied = document.execCommand('copy');
    area.remove();
    showToast(copied ? success : '浏览器未允许剪贴板访问');
  }
}

function requestMap() {
  elements.mapDialog.showModal();
  const loading = document.createElement('p');
  loading.className = 'empty-state';
  loading.textContent = '正在生成侵袭地图…';
  elements.invasionMap.replaceChildren(loading);
  worker.postMessage({ type: 'batch-scan', size: 6, gapWidth: state.config.gapWidth });
}

function renderMap(message) {
  const labels = {
    jammed: '拥堵', 'collective-advance': '集体推进', 'tumor-budding': '肿瘤出芽',
    'single-cell-escape': '单细胞逃逸', fingering: '指状侵袭'
  };
  $('#mapLegend').replaceChildren(...Object.entries(labels).map(([id, label]) => {
    const item = document.createElement('span');
    const swatch = document.createElement('i');
    swatch.dataset.phase = id;
    item.append(swatch, document.createTextNode(label));
    return item;
  }));
  elements.invasionMap.style.gridTemplateColumns = `repeat(${message.size}, 1fr)`;
  elements.invasionMap.replaceChildren(...message.points.slice().sort((a, b) => b.y - a.y || a.x - b.x).map(point => {
    const button = document.createElement('button');
    button.className = 'map-cell'; button.type = 'button'; button.dataset.phase = point.mode;
    button.title = `黏附 ${point.adhesion.toFixed(2)} · 形变 ${point.deformability.toFixed(2)} · ${labels[point.mode]}`;
    const label = document.createElement('span');
    label.textContent = labels[point.mode];
    button.append(label);
    button.addEventListener('click', () => {
      state.config = makeConfig({ ...state.config, adhesion: point.adhesion, deformability: point.deformability, presetId: 'custom' });
      setMode('explore'); renderPresets(); syncControls(); resetExperiment(); elements.mapDialog.close();
      showToast(`已载入地图格点：${labels[point.mode]}`);
    });
    return button;
  }));
}

$$('.mode-tab').forEach(button => {
  button.addEventListener('click', () => setMode(button.dataset.mode));
  button.addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    const tabs = $$('.mode-tab');
    const offset = event.key === 'ArrowRight' ? 1 : -1;
    const next = tabs[(tabs.indexOf(button) + offset + tabs.length) % tabs.length];
    setMode(next.dataset.mode);
    next.focus();
  });
});
elements.start.addEventListener('click', startOrPause);
elements.playPause.addEventListener('click', startOrPause);
elements.reset.addEventListener('click', resetExperiment);
elements.step.addEventListener('click', stepOnce);
elements.speed.addEventListener('change', () => worker.postMessage({ type: 'speed', speed: Number(elements.speed.value) }));
elements.gapRange.addEventListener('input', () => { elements.gapOutput.textContent = `${elements.gapRange.value} px`; });
elements.gapRange.addEventListener('change', () => updateConfig('gapWidth', Number(elements.gapRange.value)));
elements.seedInput.addEventListener('change', () => updateConfig('seed', Number(elements.seedInput.value)));
elements.cellCountInput.addEventListener('change', () => updateConfig('cellCount', Number(elements.cellCountInput.value)));
elements.durationInput.addEventListener('change', () => updateConfig('maxTime', Number(elements.durationInput.value)));
$$('.segmented').forEach(group => $$('button', group).forEach(button => button.addEventListener('click', () => updateConfig(group.dataset.control, Number(button.dataset.value)))));
$$('.perturb-actions button').forEach(button => {
  button.disabled = true;
  button.addEventListener('click', () => {
    if (!state.running || state.perturbation) return;
    worker.postMessage({ type: 'perturb', perturbation: button.dataset.perturb });
    $$('.perturb-actions button').forEach(item => item.disabled = true);
    showToast(`已施加：${button.textContent.trim()}`);
  });
});

$('#openScience').addEventListener('click', () => elements.scienceDialog.showModal());
$('#openKeyboard').addEventListener('click', () => elements.keyboardDialog.showModal());
$('#openMap').addEventListener('click', requestMap);
$('#copyConfig').addEventListener('click', () => copyText(JSON.stringify(state.config, null, 2), '参数 JSON 已复制'));
$('#saveLocal').addEventListener('click', () => {
  try {
    localStorage.setItem('iwt-project-v1', JSON.stringify({ schemaVersion: 1, ...exportPayload() }));
    showToast('实验设置已保存到本地浏览器');
  } catch {
    showToast('浏览器未允许本地保存，或存储空间不足');
  }
});
$('#loadLocal').addEventListener('click', () => {
  try {
    const raw = localStorage.getItem('iwt-project-v1');
    const saved = raw ? JSON.parse(raw) : null;
    if (saved?.schemaVersion !== 1 || !saved.config) throw new Error('invalid project');
    state.config = makeConfig(saved.config);
    renderPresets();
    syncControls();
    resetExperiment();
    showToast('已载入上次保存的实验设置');
  } catch {
    showToast('没有找到可载入的有效实验设置');
  }
});
$('#shareLink').addEventListener('click', () => copyText(shareUrl(), '分享链接已复制'));
$('#exportJson').addEventListener('click', () => downloadBlob(new Blob([JSON.stringify(exportPayload(), null, 2)], { type: 'application/json' }), `invasion-wind-tunnel-${Date.now()}.json`));
$('#exportCsv').addEventListener('click', () => {
  const m = state.result?.metrics || state.currentFrame?.meta.metrics || {};
  const rows = [['metric','value'], ['seed',state.config.seed], ['adhesion',state.config.adhesion], ['deformability',state.config.deformability], ['alignment',state.config.alignment], ['gap_width',state.config.gapWidth], ['first_pass_time',m.firstPassTime ?? ''], ['pass_rate',m.passRate ?? ''], ['cluster_integrity',m.integrity ?? ''], ['fragments',m.fragments ?? ''], ['mode',state.result?.mode.id ?? 'in-progress']];
  downloadBlob(new Blob([rows.map(r => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8' }), `invasion-metrics-${Date.now()}.csv`);
});
$('#exportPng').addEventListener('click', () => elements.canvas.toBlob(blob => blob && downloadBlob(blob, `invasion-frame-${Date.now()}.png`), 'image/png'));


worker.addEventListener('error', () => {
  state.running = false;
  elements.status.textContent = '模拟线程加载失败，请刷新页面后重试';
  elements.observation.textContent = '浏览器未能启动模拟线程。请确认页面通过 HTTPS 或本地服务器打开。';
  elements.start.disabled = true;
  elements.playPause.disabled = true;
  elements.step.disabled = true;
  showToast('模拟线程启动失败');
});
worker.addEventListener('messageerror', () => showToast('模拟数据传输失败，请重置实验'));

window.addEventListener('keydown', event => {
  if (event.target instanceof HTMLInputElement || event.target instanceof HTMLSelectElement || event.target instanceof HTMLTextAreaElement) return;
  if (event.code === 'Space') { event.preventDefault(); startOrPause(); }
  if (event.key.toLowerCase() === 'r') resetExperiment();
  if (event.key === 'ArrowRight') stepOnce();
  if (event.key === 'Escape' && state.replay) stopReplay();
});

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault(); state.installPrompt = event; $('#installApp').hidden = false;
});
$('#installApp').addEventListener('click', async () => {
  if (!state.installPrompt) return;
  await state.installPrompt.prompt(); state.installPrompt = null; $('#installApp').hidden = true;
});
if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch(error => console.warn('Service worker registration failed:', error)));
}

renderPresets();
syncControls();
setMode('play');
initWorker();
requestAnimationFrame(draw);
